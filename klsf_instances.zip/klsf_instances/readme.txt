K-LABELED SPANNING FOREST PROBLEM - INSTANCE FILES README
=========================================================

This archive contains instances used in the paper "The k-labeled Spanning Forest Problem", by R. Cerulli, A. Fink, M. Gentili and A. Raiconi, published in Procedia - Social and Behavioral Sciences 108 (2014), 153 – 163.

The archive contains 5 folders with name format 'inst|V|', where |V|=100,150,200,400,500. Each folder contains 40 files for a total of 200 test instances.

Each instance file name has the following name format

'instance.n=|V|_d=0.2_l=|L|instNum=i_kj'

where:

|V|= cardinality of the set of vertices  (100,150,200,400,500)
|L|= cardinality of the set of labels (|V|/4,|V|/2,|V|,1.25|V|)
i = instance identifier (1,...,10)
j = chosen k_{max} value for the related class of instances (see the paper for details)

Internally, each instance has the following format:

|V| |E| |L| j

u1 v1 l1
u2 v2 l2
(...)
ui vi li
(...)
u|E| v|E| l|E|

where the header line contains the following information:
|V|= cardinality of the set of vertices 
|E| = cardinality of the set of edges 
|L|= cardinality of the set of labels 
j = k_{max} value

while each of the following |E| lines contains:

ui, vi: endpoints of the i-th edge of the graph
li: label of the i-th edge of the graph

For more information, please contact araiconi@unisa.it or mgentili@unisa.it 


￼